# TFA3 Setup – XAMPP + phpMyAdmin + http://localhost:8080

## 1. Start XAMPP
Open the XAMPP Control Panel and start **Apache** and **MySQL**.

## 2. Create the database in phpMyAdmin
1. Open http://localhost/phpmyadmin
2. **Fresh install:** click the **SQL** tab, paste the whole content of
   `database/pos_database.sql` and click **Go**.
   (It now creates `users.avatar` already.)
3. **Already imported the old file?** Select `pos_db` > **SQL** tab, paste
   `database/add_avatar_column.sql` and click **Go**.
4. Check: `pos_db` > `users` > **Structure** shows an `avatar` column.

## 3. Put the project in place
Copy the project folder to `C:\xampp\htdocs\ci4-demo` (any folder works for `spark serve`).

## 4. Run on localhost:8080
Open CMD:

```bat
cd C:\xampp\htdocs\ci4-demo
C:\xampp\php\php.exe spark serve
```

Then open http://localhost:8080/ (`.env` already has `app.baseURL = 'http://localhost:8080/'`).
Keep the CMD window open while testing.

## 5. Pages to test
| URL | What it does |
|---|---|
| /customers | list + Edit buttons + "New Customer" |
| /customers/new | new customer (name + valid email required) |
| /customers/edit/1 | edit customer |
| /users | list with avatars + Edit buttons + "New User" |
| /users/new | new user (username required + unique, full name required) |
| /users/edit/1 | edit user + upload profile picture (JPG/PNG, max 2MB) |

## Avatar notes
- Thumbnails (150x150) are saved to `public/uploads/avatars/`; only the filename goes in `users.avatar`.
- Requires the PHP **GD** and **fileinfo** extensions (enabled by default in XAMPP;
  if missing, uncomment `extension=gd` / `extension=fileinfo` in `C:\xampp\php\php.ini`, restart).
- PHP's own upload limit must be at least 2MB (`upload_max_filesize` default in XAMPP is 40M, fine).

## Troubleshooting
- **Unknown column 'avatar'** – step 2.3 was skipped.
- **Port 8080 busy** – `php spark serve --port 8081` and change `app.baseURL` in `.env`.
- **"The action you requested is not allowed" (CSRF)** – reload the form page and submit again.
- **Avatar not saving** – make sure `public/uploads/avatars` exists and is writable.

---

## Authentication (login required)

### Database step (phpMyAdmin)
- **Already have `pos_db` from before:** select `pos_db` > **SQL** tab, paste `database/add_password_column.sql`, click **Go**.
  It adds `users.password` and sets a `password_hash()` value for every existing user.
- **Fresh install:** import `database/pos_database.sql` (already includes the password column + hashes) and skip the step above.
- Alternative using PHP itself: after the column exists, run `php spark db:seed UserPasswordSeeder`.

### Test logins
| Username | Password |
|---|---|
| admin01 | Admin@123 |
| cashier01 / cashier02 | Cashier@123 |
| manager01 | Manager@123 |
| staff01 | Staff@123 |

### Auth routes
| URL | What it does |
|---|---|
| /login | login form (public) |
| /logout | destroys the session, redirects to /login |
| /customers, /customers/new, /customers/edit/1 | protected by the `auth` filter |
| /users, /users/new, /users/edit/1 | protected by the `auth` filter |

New users created from the form now require a password (min 8 chars); on edit, leave it blank to keep the current one.
