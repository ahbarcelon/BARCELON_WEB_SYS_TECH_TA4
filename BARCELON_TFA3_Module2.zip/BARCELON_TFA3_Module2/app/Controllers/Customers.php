<?php

namespace App\Controllers;

use App\Models\CustomerModel;
use CodeIgniter\Exceptions\PageNotFoundException;

class Customers extends BaseController
{
    protected $helpers = ['form'];

    private function rules(): array
    {
        return [
            'full_name' => [
                'label'  => 'Full name',
                'rules'  => 'required|max_length[100]',
            ],
            'email' => [
                'label'  => 'Email',
                'rules'  => 'required|valid_email|max_length[100]',
            ],
            'phone' => [
                'label'  => 'Phone',
                'rules'  => 'permit_empty|max_length[20]',
            ],
        ];
    }

    public function index()
    {
        $customerModel = new CustomerModel();

        $data['customers'] = $customerModel
            ->orderBy('id', 'ASC')
            ->findAll();

        return view('customers', $data);
    }

    public function new()
    {
        return view('customer_form', [
            'title'    => 'New Customer',
            'action'   => base_url('customers/create'),
            'customer' => null,
        ]);
    }

    public function create()
    {
        if (! $this->validate($this->rules())) {
            return redirect()->back()->withInput();
        }

        (new CustomerModel())->insert([
            'full_name'  => trim($this->request->getPost('full_name')),
            'email'      => trim($this->request->getPost('email')),
            'phone'      => trim((string) $this->request->getPost('phone')),
            'created_at' => date('Y-m-d H:i:s'),
        ]);

        return redirect()->to('/customers')->with('success', 'Customer created successfully.');
    }

    public function edit(int $id)
    {
        $customer = (new CustomerModel())->find($id);

        if ($customer === null) {
            throw PageNotFoundException::forPageNotFound('Customer not found.');
        }

        return view('customer_form', [
            'title'    => 'Edit Customer',
            'action'   => base_url('customers/update/' . $id),
            'customer' => $customer,
        ]);
    }

    public function update(int $id)
    {
        $model = new CustomerModel();

        if ($model->find($id) === null) {
            throw PageNotFoundException::forPageNotFound('Customer not found.');
        }

        if (! $this->validate($this->rules())) {
            return redirect()->back()->withInput();
        }

        $model->update($id, [
            'full_name' => trim($this->request->getPost('full_name')),
            'email'     => trim($this->request->getPost('email')),
            'phone'     => trim((string) $this->request->getPost('phone')),
        ]);

        return redirect()->to('/customers')->with('success', 'Customer updated successfully.');
    }
}
