<?php

namespace App\Database\Seeds;

use CodeIgniter\Database\Seeder;

/**
 * Alternative to database/add_password_column.sql:
 *   php spark db:seed UserPasswordSeeder
 * (run AFTER the password column exists)
 */
class UserPasswordSeeder extends Seeder
{
    public function run()
    {
        $passwords = [
            'admin01'   => 'Admin@123',
            'cashier01' => 'Cashier@123',
            'cashier02' => 'Cashier@123',
            'manager01' => 'Manager@123',
            'staff01'   => 'Staff@123',
        ];

        foreach ($passwords as $username => $plain) {
            $this->db->table('users')
                ->where('username', $username)
                ->update(['password' => password_hash($plain, PASSWORD_DEFAULT)]);
        }
    }
}
