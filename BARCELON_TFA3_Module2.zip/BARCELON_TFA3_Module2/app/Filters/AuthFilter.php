<?php

namespace App\Filters;

use CodeIgniter\Filters\FilterInterface;
use CodeIgniter\HTTP\RequestInterface;
use CodeIgniter\HTTP\ResponseInterface;

/**
 * Blocks a route unless a user is logged in.
 */
class AuthFilter implements FilterInterface
{
    public function before(RequestInterface $request, $arguments = null)
    {
        $session = session();

        if ($session->get('isLoggedIn') === true) {
            return; // logged in: continue to the controller
        }

        // Remember the page they wanted (GET only) so login can send them back.
        if (strtolower($request->getMethod()) === 'get') {
            $session->set('redirect_after_login', (string) current_url());
        }

        return redirect()->to('/login')->with('error', 'Please log in to continue.');
    }

    public function after(RequestInterface $request, ResponseInterface $response, $arguments = null)
    {
        // nothing to do
    }
}
