<?php
$errors = session('errors') ?? [];
$val = static fn (string $f) => old($f, $customer[$f] ?? '');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="<?= base_url('assets/css/valorant.css') ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= esc($title) ?></title>
</head>
<body>
    <?= view('partials/nav') ?>

    <hr>

    <div class="container">
        <h1><?= esc($title) ?></h1>

        <?php if ($errors): ?>
            <div class="alert alert-error">
                <ul>
                    <?php foreach ($errors as $error): ?>
                        <li><?= esc($error) ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
        <?php endif; ?>

        <form action="<?= $action ?>" method="post" novalidate>
            <?= csrf_field() ?>

            <div class="form-group">
                <label for="full_name">Full Name *</label>
                <input type="text" id="full_name" name="full_name" maxlength="100" value="<?= esc($val('full_name')) ?>">
            </div>

            <div class="form-group">
                <label for="email">Email Address *</label>
                <input type="email" id="email" name="email" maxlength="100" value="<?= esc($val('email')) ?>">
            </div>

            <div class="form-group">
                <label for="phone">Phone Number</label>
                <input type="text" id="phone" name="phone" maxlength="20" value="<?= esc($val('phone')) ?>">
            </div>

            <div class="form-actions">
                <button type="submit" class="btn">Save</button>
                <a href="<?= base_url('customers') ?>" class="btn btn-secondary">Cancel</a>
            </div>
        </form>
    </div>
</body>
</html>
