-- Run this ONLY if you already imported the old pos_database.sql (without avatar).
USE pos_db;

ALTER TABLE users
    ADD COLUMN avatar VARCHAR(255) DEFAULT NULL AFTER full_name;
