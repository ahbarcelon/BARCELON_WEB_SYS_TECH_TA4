-- Run in phpMyAdmin: select pos_db > SQL tab > paste > Go.
-- Adds users.password and sets a password_hash() (bcrypt) value for each existing user.
USE pos_db;

ALTER TABLE users
    ADD COLUMN password VARCHAR(255) DEFAULT NULL AFTER full_name;

UPDATE users SET password = '$2y$10$JMBtlBoAIte8WD7TM8dItuHed7cCGe25.s.4sNdyNrfK3jiU9nmIm' WHERE username = 'admin01';    -- Admin@123
UPDATE users SET password = '$2y$10$0jCxOleJN1Hjq75PupHbEeaVh.wWjVmW0Hwe3lo24Q5USXJxzpAhm' WHERE username = 'cashier01';  -- Cashier@123
UPDATE users SET password = '$2y$10$xqXXqKHG.MVTLye6LHb4HeT029qtM3paEmK5fWRQBEuttcY19aZAO' WHERE username = 'cashier02';  -- Cashier@123
UPDATE users SET password = '$2y$10$TIdqyh3bLfAsmyz9rcV32.CWbLuvSws3GtYyEXxnPp9OCi07iQdou' WHERE username = 'manager01';  -- Manager@123
UPDATE users SET password = '$2y$10$utd6z/XY/8ZcRusgSLyYTut3Rby6Oz/N0hnYZ.ZbGdIy5I1k36SKy' WHERE username = 'staff01';    -- Staff@123
