CREATE DATABASE IF NOT EXISTS pos_db
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_general_ci;

USE pos_db;

CREATE TABLE IF NOT EXISTS customers (
    id INT AUTO_INCREMENT PRIMARY KEY,
    full_name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL,
    phone VARCHAR(20),
    created_at DATETIME NOT NULL
);

CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    full_name VARCHAR(100) NOT NULL,
    password VARCHAR(255) DEFAULT NULL,
    avatar VARCHAR(255) DEFAULT NULL,
    created_at DATETIME NOT NULL
);

INSERT INTO customers (full_name, email, phone, created_at) VALUES
('Juan Dela Cruz', 'juan.delacruz@example.com', '09171234567', '2026-09-26 09:00:00'),
('Maria Santos', 'maria.santos@example.com', '09182345678', '2026-09-26 09:05:00'),
('Paolo Reyes', 'paolo.reyes@example.com', '09193456789', '2026-09-26 09:10:00'),
('Angela Garcia', 'angela.garcia@example.com', '09204567890', '2026-09-26 09:15:00'),
('Joshua Mendoza', 'joshua.mendoza@example.com', '09215678901', '2026-09-26 09:20:00');

INSERT INTO users (username, full_name, password, created_at) VALUES
('admin01', 'Aaron Barcelon', '$2y$10$JMBtlBoAIte8WD7TM8dItuHed7cCGe25.s.4sNdyNrfK3jiU9nmIm', '2026-09-26 09:00:00'),
('cashier01', 'Carla Ramos', '$2y$10$0jCxOleJN1Hjq75PupHbEeaVh.wWjVmW0Hwe3lo24Q5USXJxzpAhm', '2026-09-26 09:05:00'),
('cashier02', 'Daniel Flores', '$2y$10$xqXXqKHG.MVTLye6LHb4HeT029qtM3paEmK5fWRQBEuttcY19aZAO', '2026-09-26 09:10:00'),
('manager01', 'Sophia Lim', '$2y$10$TIdqyh3bLfAsmyz9rcV32.CWbLuvSws3GtYyEXxnPp9OCi07iQdou', '2026-09-26 09:15:00'),
('staff01', 'Mark Villanueva', '$2y$10$utd6z/XY/8ZcRusgSLyYTut3Rby6Oz/N0hnYZ.ZbGdIy5I1k36SKy', '2026-09-26 09:20:00');
